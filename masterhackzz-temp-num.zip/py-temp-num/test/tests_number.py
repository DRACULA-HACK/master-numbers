def test_main_menu():
    assert main_menu() == None
